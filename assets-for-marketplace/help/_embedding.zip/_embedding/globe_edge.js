/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};
var opts = {};
var resources = [
];
var symbols = {
"stage": {
    version: "3.0.0",
    minimumCompatibleVersion: "3.0.0",
    build: "3.0.0.322",
    baseState: "Base State",
    scaleToFit: "none",
    centerStage: "horizontal",
    initialState: "Base State",
    gpuAccelerate: false,
    resizeInstances: false,
    content: {
            dom: [
            {
                id: 'globe',
                type: 'rect',
                rect: ['300px', '100px','auto','auto','auto', 'auto'],
                userClass: "globe"
            }],
            symbolInstances: [
            {
                id: 'globe',
                symbolName: 'globe',
                autoPlay: {

                }
            }
            ]
        },
    states: {
        "Base State": {
            "${_globe}": [
                ["style", "left", '300px'],
                ["style", "overflow", 'visible']
            ],
            "${_Stage}": [
                ["color", "background-color", 'rgba(255,255,255,1.00)'],
                ["style", "overflow", 'hidden'],
                ["style", "height", '400px'],
                ["style", "width", '800px']
            ]
        }
    },
    timelines: {
        "Default Timeline": {
            fromState: "Base State",
            toState: "",
            duration: 4000,
            autoPlay: true,
            timeline: [
            ]
        }
    }
},
"globe": {
    version: "3.0.0",
    minimumCompatibleVersion: "3.0.0",
    build: "3.0.0.322",
    baseState: "Base State",
    scaleToFit: "none",
    centerStage: "none",
    initialState: "Base State",
    gpuAccelerate: false,
    resizeInstances: false,
    content: {
            dom: [
                {
                    type: 'image',
                    display: 'block',
                    rect: ['-5px', '-5px', '210px', '210px', 'auto', 'auto'],
                    id: 'sphere',
                    fill: ['rgba(0,0,0,0)', 'images/sphere.svg', '0px', '0px']
                },
                {
                    type: 'image',
                    rect: ['0px', '184px', '200px', '30px', 'auto', 'auto'],
                    id: 'outer-shadow',
                    opacity: 1,
                    display: 'block',
                    fill: ['rgba(0,0,0,0)', 'images/outer-shadow.svg', '0px', '0px']
                },
                {
                    type: 'image',
                    rect: ['2px', '0px', '197px', '197px', 'auto', 'auto'],
                    filter: [0, 0, 1, 1, 0, 0, 0, 0, 'rgba(0,0,0,0)', 0, 0, 0],
                    id: 'reflections-2nd',
                    opacity: 1,
                    display: 'block',
                    fill: ['rgba(0,0,0,0)', 'images/reflections.svg', '0px', '0px']
                },
                {
                    id: 'continents-animation',
                    type: 'rect',
                    rect: ['0', '0px', 'auto', 'auto', 'auto', 'auto'],
                    userClass: 'continents'
                },
                {
                    type: 'image',
                    rect: ['2px', '0px', '197px', '197px', 'auto', 'auto'],
                    filter: [0, 0, 1, 1, 0, 0, 0, 0, 'rgba(0,0,0,0)', 0, 0, 0],
                    id: 'reflections',
                    opacity: 1,
                    display: 'block',
                    fill: ['rgba(0,0,0,0)', 'images/reflections.svg', '0px', '0px']
                }
            ],
            symbolInstances: [
            {
                id: 'continents-animation',
                symbolName: 'continents-animation',
                autoPlay: {

               }
            }            ]
        },
    states: {
        "Base State": {
            "${_continents-animation}": [
                ["style", "top", '0px']
            ],
            "${_reflections}": [
                ["style", "top", '0px'],
                ["style", "height", '197px'],
                ["style", "display", 'block'],
                ["style", "opacity", '1'],
                ["style", "left", '2px'],
                ["style", "width", '197px']
            ],
            "${symbolSelector}": [
                ["style", "height", '200px'],
                ["style", "width", '200px'],
                ["style", "overflow", 'visible']
            ],
            "${_outer-shadow}": [
                ["style", "top", '184px'],
                ["style", "opacity", '1'],
                ["style", "left", '0px'],
                ["style", "display", 'block']
            ],
            "${_sphere}": [
                ["style", "top", '-5px'],
                ["style", "height", '210px'],
                ["style", "display", 'block'],
                ["style", "left", '-5px'],
                ["style", "width", '210px']
            ],
            "${_reflections-2nd}": [
                ["style", "top", '0px'],
                ["style", "height", '197px'],
                ["style", "display", 'block'],
                ["style", "opacity", '1'],
                ["style", "left", '2px'],
                ["style", "width", '197px']
            ]
        }
    },
    timelines: {
        "Default Timeline": {
            fromState: "Base State",
            toState: "",
            duration: 4000,
            autoPlay: true,
            timeline: [
                { id: "eid861", tween: [ "style", "${_reflections-2nd}", "display", 'block', { fromValue: 'block'}], position: 0, duration: 0 },
                { id: "eid311", tween: [ "style", "${_outer-shadow}", "display", 'block', { fromValue: 'block'}], position: 0, duration: 0 },
                { id: "eid312", tween: [ "style", "${_reflections}", "display", 'block', { fromValue: 'block'}], position: 0, duration: 0 },
                { id: "eid870", tween: [ "style", "${_sphere}", "display", 'block', { fromValue: 'block'}], position: 0, duration: 0 }            ]
        }
    }
},
"flatmap-two": {
    version: "3.0.0",
    minimumCompatibleVersion: "3.0.0",
    build: "3.0.0.322",
    baseState: "Base State",
    scaleToFit: "none",
    centerStage: "none",
    initialState: "Base State",
    gpuAccelerate: false,
    resizeInstances: false,
    content: {
            dom: [
                {
                    id: 'worldmap-flat',
                    type: 'image',
                    rect: ['0px', '7px', '860px', '410px', 'auto', 'auto'],
                    fill: ['rgba(0,0,0,0)', 'images/worldmap-flat.svg', '0px', '0px']
                }
            ],
            symbolInstances: [
            ]
        },
    states: {
        "Base State": {
            "${_worldmap-flat}": [
                ["style", "left", '0px'],
                ["style", "top", '7px']
            ],
            "${symbolSelector}": [
                ["style", "height", '200px'],
                ["style", "overflow", 'visible'],
                ["style", "width", '860px']
            ]
        }
    },
    timelines: {
        "Default Timeline": {
            fromState: "Base State",
            toState: "",
            duration: 0,
            autoPlay: true,
            timeline: [
            ]
        }
    }
},
"continents-animation": {
    version: "3.0.0",
    minimumCompatibleVersion: "3.0.0",
    build: "3.0.0.322",
    baseState: "Base State",
    scaleToFit: "none",
    centerStage: "none",
    initialState: "Base State",
    gpuAccelerate: false,
    resizeInstances: false,
    content: {
            dom: [
                {
                    type: 'rect',
                    display: 'block',
                    opacity: 1,
                    id: 'flatmap-back',
                    rect: ['0px', '-210px', 'auto', 'auto', 'auto', 'auto']
                },
                {
                    display: 'block',
                    type: 'rect',
                    rect: ['0px', '0px', 'auto', 'auto', 'auto', 'auto'],
                    id: 'flatmap-front'
                },
                {
                    rect: ['-5px', '-5px', '210px', '210px', 'auto', 'auto'],
                    id: 'inner-shadow',
                    type: 'image',
                    display: 'block',
                    fill: ['rgba(0,0,0,0)', 'images/inner-shadow.svg', '0px', '0px']
                }
            ],
            symbolInstances: [
            {
                id: 'flatmap-front',
                symbolName: 'flatmap-two',
                autoPlay: {

               }
            },
            {
                id: 'flatmap-back',
                symbolName: 'flatmap-two',
                autoPlay: {

               }
            }            ]
        },
    states: {
        "Base State": {
            "${symbolSelector}": [
                ["style", "height", '200px'],
                ["style", "width", '200px'],
                ["style", "overflow", 'hidden']
            ],
            "${_inner-shadow}": [
                ["style", "top", '-5px'],
                ["style", "display", 'block'],
                ["style", "height", '210px'],
                ["style", "left", '-5px'],
                ["style", "width", '210px']
            ],
            "${_flatmap-back}": [
                ["style", "top", '-210px'],
                ["style", "opacity", '1'],
                ["style", "left", '0px'],
                ["style", "display", 'block']
            ],
            "${_flatmap-front}": [
                ["style", "top", '0px'],
                ["style", "left", '-430px'],
                ["style", "display", 'block']
            ]
        }
    },
    timelines: {
        "Default Timeline": {
            fromState: "Base State",
            toState: "",
            duration: 4000,
            autoPlay: true,
            timeline: [
                { id: "eid872", tween: [ "style", "${_flatmap-front}", "display", 'block', { fromValue: 'block'}], position: 0, duration: 0 },
                { id: "eid873", tween: [ "style", "${_flatmap-back}", "display", 'block', { fromValue: 'block'}], position: 0, duration: 0 },
                { id: "eid860", tween: [ "style", "${_flatmap-front}", "left", '0px', { fromValue: '-430px'}], position: 0, duration: 4000 },
                { id: "eid874", tween: [ "style", "${_inner-shadow}", "display", 'block', { fromValue: 'block'}], position: 0, duration: 0 },
                { id: "eid851", tween: [ "style", "${_flatmap-back}", "left", '-430px', { fromValue: '0px'}], position: 0, duration: 4000 }            ]
        }
    }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources, opts);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-10260560");
